package TpiE7;

public class Partido {

}
