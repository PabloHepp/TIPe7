package TpiE7;

public enum ResultadoEnum {

}
